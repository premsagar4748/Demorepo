import {
  Injectable,
  NgModule,
  Pipe,
  setClassMetadata,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdefinePipe
} from "./chunk-7SEQXISM.js";
import "./chunk-43Q5NIZN.js";
import "./chunk-N2GUINJT.js";
import "./chunk-OWGIDFST.js";
import "./chunk-V4F5PRXT.js";

// node_modules/ngx-filter-pipe/fesm2022/ngx-filter-pipe.mjs
var FilterPipe = class _FilterPipe {
  static isFoundOnWalking(value, key) {
    let walker = value;
    let found = false;
    do {
      if (walker.hasOwnProperty(key) || Object.getOwnPropertyDescriptor(walker, key)) {
        found = true;
        break;
      }
    } while (walker = Object.getPrototypeOf(walker));
    return found;
  }
  static isNumber(value) {
    return !isNaN(parseInt(value, 10)) && isFinite(value);
  }
  /**
   * Checks function's value if type is function otherwise same value
   */
  static getValue(value) {
    return typeof value === "function" ? value() : value;
  }
  filterByString(filter) {
    if (filter) {
      filter = filter.toLowerCase();
    }
    return (value) => !filter || (value ? ("" + value).toLowerCase().indexOf(filter) !== -1 : false);
  }
  filterByBoolean(filter) {
    return (value) => Boolean(value) === filter;
  }
  filterByObject(filter) {
    return (value) => {
      for (const key in filter) {
        if (key === "$or") {
          if (!this.filterByOr(filter.$or)(_FilterPipe.getValue(value))) {
            return false;
          }
          continue;
        }
        if (!value || !_FilterPipe.isFoundOnWalking(value, key)) {
          return false;
        }
        if (!this.isMatching(filter[key], _FilterPipe.getValue(value[key]))) {
          return false;
        }
      }
      return true;
    };
  }
  isMatching(filter, val) {
    switch (typeof filter) {
      case "boolean":
        return this.filterByBoolean(filter)(val);
      case "string":
        return this.filterByString(filter)(val);
      case "object":
        return this.filterByObject(filter)(val);
    }
    return this.filterDefault(filter)(val);
  }
  /**
   * Filter value by $or
   */
  filterByOr(filter) {
    return (value) => {
      const length = filter.length;
      const arrayComparison = (i) => value.indexOf(filter[i]) !== -1;
      const otherComparison = (i) => this.isMatching(filter[i], value);
      const comparison = Array.isArray(value) ? arrayComparison : otherComparison;
      for (let i = 0; i < length; i++) {
        if (comparison(i)) {
          return true;
        }
      }
      return false;
    };
  }
  /**
   * Default filterDefault function
   */
  filterDefault(filter) {
    return (value) => filter === void 0 || filter == value;
  }
  transform(array, filter) {
    if (!array) {
      return array;
    }
    switch (typeof filter) {
      case "boolean":
        return array.filter(this.filterByBoolean(filter));
      case "string":
        if (_FilterPipe.isNumber(filter)) {
          return array.filter(this.filterDefault(filter));
        }
        return array.filter(this.filterByString(filter));
      case "object":
        return array.filter(this.filterByObject(filter));
      case "function":
        return array.filter(filter);
    }
    return array.filter(this.filterDefault(filter));
  }
  static ɵfac = function FilterPipe_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _FilterPipe)();
  };
  static ɵpipe = ɵɵdefinePipe({
    name: "filterBy",
    type: _FilterPipe,
    pure: false,
    standalone: false
  });
  static ɵprov = ɵɵdefineInjectable({
    token: _FilterPipe,
    factory: _FilterPipe.ɵfac
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FilterPipe, [{
    type: Pipe,
    args: [{
      name: "filterBy",
      pure: false
    }]
  }, {
    type: Injectable
  }], null, null);
})();
var FilterPipeModule = class _FilterPipeModule {
  static ɵfac = function FilterPipeModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _FilterPipeModule)();
  };
  static ɵmod = ɵɵdefineNgModule({
    type: _FilterPipeModule,
    declarations: [FilterPipe],
    exports: [FilterPipe]
  });
  static ɵinj = ɵɵdefineInjector({
    providers: [FilterPipe]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FilterPipeModule, [{
    type: NgModule,
    args: [{
      declarations: [FilterPipe],
      providers: [FilterPipe],
      exports: [FilterPipe]
    }]
  }], null, null);
})();
export {
  FilterPipe,
  FilterPipeModule
};
//# sourceMappingURL=ngx-filter-pipe.js.map
