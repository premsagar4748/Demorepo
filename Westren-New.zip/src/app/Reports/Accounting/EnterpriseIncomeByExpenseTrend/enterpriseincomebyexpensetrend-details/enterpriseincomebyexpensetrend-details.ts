import { Component } from '@angular/core';

@Component({
  selector: 'app-enterpriseincomebyexpensetrend-details',
  imports: [],
  templateUrl: './enterpriseincomebyexpensetrend-details.html',
  styleUrl: './enterpriseincomebyexpensetrend-details.scss'
})
export class EnterpriseincomebyexpensetrendDetails {

}
