import { Component } from '@angular/core';

@Component({
  selector: 'app-income-budget-variables',
  imports: [],
  templateUrl: './income-budget-variables.html',
  styleUrl: './income-budget-variables.scss'
})
export class IncomeBudgetVariables {

}
